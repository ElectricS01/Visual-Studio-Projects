﻿namespace Sac_task_3_player_information
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_first = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_age = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_number = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_sur = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lst_box = new System.Windows.Forms.ListBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_display = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_forward = new System.Windows.Forms.Button();
            this.btn_defender = new System.Windows.Forms.Button();
            this.btn_mid = new System.Windows.Forms.Button();
            this.txt_pos = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label1.Location = new System.Drawing.Point(137, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(372, 51);
            this.label1.TabIndex = 0;
            this.label1.Text = "Player Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(38, 54);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "Firstname:";
            // 
            // txt_first
            // 
            this.txt_first.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txt_first.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txt_first.ForeColor = System.Drawing.SystemColors.Control;
            this.txt_first.Location = new System.Drawing.Point(126, 50);
            this.txt_first.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_first.Name = "txt_first";
            this.txt_first.Size = new System.Drawing.Size(89, 44);
            this.txt_first.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(38, 80);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 37);
            this.label3.TabIndex = 3;
            this.label3.Text = "Position:";
            // 
            // txt_age
            // 
            this.txt_age.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txt_age.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txt_age.ForeColor = System.Drawing.SystemColors.Control;
            this.txt_age.Location = new System.Drawing.Point(126, 103);
            this.txt_age.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_age.Name = "txt_age";
            this.txt_age.Size = new System.Drawing.Size(89, 44);
            this.txt_age.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(38, 107);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 37);
            this.label4.TabIndex = 5;
            this.label4.Text = "Age:";
            // 
            // txt_number
            // 
            this.txt_number.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txt_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txt_number.ForeColor = System.Drawing.SystemColors.Control;
            this.txt_number.Location = new System.Drawing.Point(354, 73);
            this.txt_number.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_number.Name = "txt_number";
            this.txt_number.Size = new System.Drawing.Size(45, 44);
            this.txt_number.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(222, 76);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(257, 37);
            this.label6.TabIndex = 9;
            this.label6.Text = "Jumper Number:";
            // 
            // txt_sur
            // 
            this.txt_sur.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txt_sur.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txt_sur.ForeColor = System.Drawing.SystemColors.Control;
            this.txt_sur.Location = new System.Drawing.Point(304, 47);
            this.txt_sur.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_sur.Name = "txt_sur";
            this.txt_sur.Size = new System.Drawing.Size(96, 44);
            this.txt_sur.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(222, 50);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(156, 37);
            this.label7.TabIndex = 7;
            this.label7.Text = "Surname:";
            // 
            // lst_box
            // 
            this.lst_box.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lst_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lst_box.ForeColor = System.Drawing.SystemColors.Control;
            this.lst_box.FormattingEnabled = true;
            this.lst_box.ItemHeight = 37;
            this.lst_box.Location = new System.Drawing.Point(142, 145);
            this.lst_box.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lst_box.Name = "lst_box";
            this.lst_box.Size = new System.Drawing.Size(178, 78);
            this.lst_box.TabIndex = 11;
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_add.Location = new System.Drawing.Point(4, 244);
            this.btn_add.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(104, 44);
            this.btn_add.TabIndex = 12;
            this.btn_add.Text = "Add player to file";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_display
            // 
            this.btn_display.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_display.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_display.Location = new System.Drawing.Point(116, 244);
            this.btn_display.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_display.Name = "btn_display";
            this.btn_display.Size = new System.Drawing.Size(104, 44);
            this.btn_display.TabIndex = 13;
            this.btn_display.Text = "Display File";
            this.btn_display.UseVisualStyleBackColor = false;
            this.btn_display.Click += new System.EventHandler(this.btn_display_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_clear.Location = new System.Drawing.Point(227, 244);
            this.btn_clear.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(104, 44);
            this.btn_clear.TabIndex = 14;
            this.btn_clear.Text = "Clear Form";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_close.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_close.Location = new System.Drawing.Point(338, 244);
            this.btn_close.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(104, 44);
            this.btn_close.TabIndex = 15;
            this.btn_close.Text = "Close App";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // btn_forward
            // 
            this.btn_forward.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_forward.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_forward.Location = new System.Drawing.Point(60, 292);
            this.btn_forward.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_forward.Name = "btn_forward";
            this.btn_forward.Size = new System.Drawing.Size(104, 44);
            this.btn_forward.TabIndex = 16;
            this.btn_forward.Text = "Display Forwards";
            this.btn_forward.UseVisualStyleBackColor = false;
            this.btn_forward.Click += new System.EventHandler(this.btn_forward_Click);
            // 
            // btn_defender
            // 
            this.btn_defender.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_defender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_defender.Location = new System.Drawing.Point(172, 292);
            this.btn_defender.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_defender.Name = "btn_defender";
            this.btn_defender.Size = new System.Drawing.Size(104, 44);
            this.btn_defender.TabIndex = 17;
            this.btn_defender.Text = "Display Defenders";
            this.btn_defender.UseVisualStyleBackColor = false;
            this.btn_defender.Click += new System.EventHandler(this.btn_defender_Click);
            // 
            // btn_mid
            // 
            this.btn_mid.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_mid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_mid.Location = new System.Drawing.Point(284, 292);
            this.btn_mid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_mid.Name = "btn_mid";
            this.btn_mid.Size = new System.Drawing.Size(104, 44);
            this.btn_mid.TabIndex = 18;
            this.btn_mid.Text = "Display Midfielders";
            this.btn_mid.UseVisualStyleBackColor = false;
            this.btn_mid.Click += new System.EventHandler(this.btn_mid_Click);
            // 
            // txt_pos
            // 
            this.txt_pos.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txt_pos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txt_pos.ForeColor = System.Drawing.SystemColors.Control;
            this.txt_pos.FormattingEnabled = true;
            this.txt_pos.Items.AddRange(new object[] {
            "Forward",
            "Defender",
            "Midfielder"});
            this.txt_pos.Location = new System.Drawing.Point(126, 76);
            this.txt_pos.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_pos.Name = "txt_pos";
            this.txt_pos.Size = new System.Drawing.Size(89, 45);
            this.txt_pos.TabIndex = 19;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(444, 344);
            this.Controls.Add(this.txt_pos);
            this.Controls.Add(this.btn_mid);
            this.Controls.Add(this.btn_defender);
            this.Controls.Add(this.btn_forward);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_display);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.lst_box);
            this.Controls.Add(this.txt_number);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_sur);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_age);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_first);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_first;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_age;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_number;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_sur;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox lst_box;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_display;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Button btn_forward;
        private System.Windows.Forms.Button btn_defender;
        private System.Windows.Forms.Button btn_mid;
        private System.Windows.Forms.ComboBox txt_pos;
    }
}

